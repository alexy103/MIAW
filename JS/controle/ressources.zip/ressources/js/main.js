document.querySelector('.videos').classList.add('cacher');

document.querySelector('#videos').addEventListener('click', () => {
  document.querySelector('.images').classList.add('cacher');
  document.querySelector('.images').classList.remove('afficher');

  document.querySelector('.videos').classList.add('afficher');
  document.querySelector('.videos').classList.remove('cacher');
});

document.querySelector('#images').addEventListener('click', () => {
  document.querySelector('.videos').classList.add('cacher');
  document.querySelector('.videos').classList.remove('afficher');

  document.querySelector('.images').classList.add('afficher');
  document.querySelector('.images').classList.remove('cacher');
});

function esImage(i) {
  return i.endsWith('.jpg');
}

fetch('https://abourmau.lpmiaw.univ-lr.fr/2022/miaw/man-js/')
  .then((response) => response.json())
  .then((data) => {
    data.images.forEach((e) => {
      if (!esImage(e.large_url)) {
        const video = document.createElement('video');
        video.src = e.large_url;
        document.querySelector('aside').appendChild(video);
      }
    });
    // On crée une image et l'ajoute au HTML
    const img1 = document.createElement('img');
    img1.src = data.images[0].large_url;
    document.querySelector('figure').appendChild(img1);

    // On crée une description et l'ajoute au HTML
    data.images.slice(1, data.images.length - 1).forEach((e) => {
      if (esImage(e.large_url)) {
        const img = document.createElement('img');
        img.src = data.images[0].large_url;
        img.classList.add('cacher');

        const figcaption = document.createElement('figcaption');
        figcaption.innerText = e.large_url.slice(56, -4).replaceAll('_', ' ');

        document.querySelector('figure').appendChild(img);
        document.querySelector('figure').appendChild(figcaption);
      }
    });
  })
  .catch((err) => {
    console.log(err.message);
  });
